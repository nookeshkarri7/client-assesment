import {BrowserRouter,Route,Switch} from "react-router-dom"
import Movies from "./components/Movies"
import MovieDetails from "./components/MovieDetails"
import AddMovie from "./components/AddMovie"

function App() {
  return (
    <BrowserRouter>
      <Switch>
        <Route exact path="/" component={Movies}/>
        <Route exact path="/addmovie" component={AddMovie}/>
        <Route exact path="/:movie" component={MovieDetails}/>
      </Switch>
    </BrowserRouter>
    
  );
}

export default App;
