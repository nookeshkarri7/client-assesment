import React,{useState,useEffect} from 'react'
import axios from 'axios'
import "./index.css"

const MovieDetails=(props) =>{
    const {match}=props
    const movieName=(match.params.movie)
    const [eachMovie,setEachMovie]=useState([])

    const getData=async()=>{
        const response=await axios.get(`http://localhost:4000/${movieName}`)
        setEachMovie(response.data[0])
        console.log(response.data)
    }

    useEffect(()=>getData())
    return (
        <div className="each-movie-container movie-details">
            <h1>Movie Details </h1>
            <h1 className="movie-title">Movie Name : {eachMovie.name}</h1>
            <p  className="movie-rating">Rating : {eachMovie.rating}</p>
            <p  className="movie-date">Released Date : {eachMovie.releasedDate}</p>
        </div>
        
    )
}

export default MovieDetails
