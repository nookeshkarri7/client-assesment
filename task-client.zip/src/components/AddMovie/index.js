import { useState } from "react"
import axios from "axios"
import "./index.css"

const AddMovie=(props)=>{
    const [movieName,setNewMovieName]=useState("")
    const [movieRating,setNewmovieRating]=useState(0)
    const [movieDate,setNewMovieDate]=useState("")
    const [showMsg,setShowMsg]=useState("")

    const dataAdded=()=>{
        const {history}=props
        history.push("/")
    }

    const addMovie=async(event)=>{
        event.preventDefault()
        const newMovieData={
            name:movieName,
            rating:movieRating,
            releasedDate:movieDate
        }
        if (movieName!=="" && movieRating!=="" && movieDate!==""){
            const response=await axios.post("http://localhost:4000/addmovie",newMovieData)
            console.log(response)
            setShowMsg("")
            dataAdded()
        }
        else{
            setShowMsg("Please enter valid input")
        }
     }

    return(
        <form onSubmit={addMovie} className="input-form">
            <label htmlFor="name">Movie Name</label>
            <input type='text' id="name" className="input" onChange={(e)=>setNewMovieName(e.target.value)}/>
            <label htmlFor="name">Rating</label>
            <input type='number' id="rating" className="input" onChange={(e)=>setNewmovieRating(e.target.value)}/>
            <label htmlFor="name">Released Date</label>
            <input type='text' id="date" className="input" onChange={(e)=>setNewMovieDate(e.target.value)}/>
            <button type="submit" className="submit-button">Add Movie</button>
            {showMsg && <p>{showMsg}</p>}
        </form>
    )
}

export default AddMovie