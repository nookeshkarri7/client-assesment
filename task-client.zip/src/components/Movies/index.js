import React,{useState,useEffect} from 'react'
import axios from "axios"
import { Link } from 'react-router-dom'
import MovieItem from "../MovieItem"
import "./index.css"

function Movies() {
    const [movieData,setMovieData]=useState([])

    const getData=async()=>{
        const response=await axios.get("http://localhost:4000/")
        setMovieData(response.data)
        console.log(response.data)
    }

    useEffect(()=>{
        getData()
    },[])

    return (
        <div>
            <div >
                <Link to="/addmovie" className="add-container">
                <button className="add-new-movie-button">Add New Movie</button>
            </Link>
            
            </div>
            <div   className="all-movies">
            {movieData.map(eachMovie=>
            <ul ><MovieItem key={eachMovie.name} data={eachMovie}/></ul>)}
            </div>
        </div>
    )
}

export default Movies
