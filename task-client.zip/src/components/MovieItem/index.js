import React from 'react'
import {Link} from "react-router-dom"
import "./index.css"

function MovieItem(props) {
    const {data}=props
    return (
        <Link className="link-item" to={`/${data.name}`}><li className="each-movie-container">
            <h1 className="movie-title">Movie Name : {data.name}</h1>
            <p  className="movie-rating">Rating : {data.rating}</p>
            <p  className="movie-date">Released Date : {data.releasedDate}</p>
        </li></Link>
    )
}

export default MovieItem
